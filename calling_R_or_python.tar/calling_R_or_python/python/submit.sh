#!/bin/bash

condor_submit use_python.sub
