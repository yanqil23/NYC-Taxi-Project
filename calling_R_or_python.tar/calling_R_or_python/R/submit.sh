#!/bin/bash

condor_submit use_R.sub
