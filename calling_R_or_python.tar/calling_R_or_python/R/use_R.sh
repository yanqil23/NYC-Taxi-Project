#!/bin/bash

Rscript use_R.R $1 $2 # note: the two actual command-line arguments
                      # are in myscript.sub's "arguments = " line
