#!/bin/bash

rm -f log/* output/* error/* use_R_[012].txt interactive.log

exit 0
